To use those under Momentum or Xtreme firmwares :


1. Choose up to 3 pictures.


2. Rename the files accordingly to moods :

HAPPY :
passport_happy_46x49.bmx

OKAY :
passport_okay_46x49.bmx

BAD/ANGRY :
passport_bad_46x49.bmx


3. Copy them in asset-pack passport folder :

SD/asset_packs/yourassetpackcustomname/Icons/Passport/


O_oV


