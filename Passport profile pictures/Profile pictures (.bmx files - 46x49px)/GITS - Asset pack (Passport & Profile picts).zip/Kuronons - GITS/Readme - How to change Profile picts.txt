GHOST IN THE SHELL - Asset Pack by Kuronons

************************ 

This asset pack contains a passport background pict along with 9 different profile picts :

 Aoi (Laughing Man)
 Hideo Kuze (Individual 11) 
 Project 2501 (Puppet Master)
 
 And the 6 members of the Section 9 :
 Aramaki 
 Kusanagi
 Batou
 Togusa
 Ishikawa
 Saito
 

On MOMENTUM, only 3 are used based on the Flipper's mood. (Happy, okay, angry)

By default in this pack :
HAPPY = Kusanagi
OKAY = Batou
ANGRY = Project 2501

************************ 

CHANGING ONE (or more) profile pict(s),

1. go to : SD/asset_packs/Kuronons - GITS/Icons/Passport/

There you will find a 13 files :
  passport_128x64.bmx = the GITS themed passport background 
  -> Remove (or Rename) if you don't want to use it

The 3 default / used profile pict :
  passport_happy_46x49.bmx (HAPPY)
  passport_okay_46x49.bmx (OKAY)
  passport_bad_46x49.bmx (ANGRY)

And the 9 profile picts named GITS-Nameofcharacter.bmx 



2. Delete the default one(s) you want to get rid of



3. Duplicate a GITS-Nameofcharacter.bmx file (or use your own asset)...



4. ...and rename it accordingly. (name of the default file you previously deleted...)



5. Reboot Flip. Done.


O_oV


